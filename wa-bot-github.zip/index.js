const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason
} = require("@whiskeysockets/baileys");

const P = require("pino");
const qrcode = require("qrcode-terminal");

async function startBot() {
  const { state, saveCreds } = await useMultiFileAuthState("./session");

  const sock = makeWASocket({
    auth: state,
    logger: P({ level: "silent" })
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      console.log("\nScan QR berikut dengan WhatsApp:\n");
      qrcode.generate(qr, { small: true });
    }

    if (connection === "open") {
      console.log("Bot WhatsApp berhasil terhubung!");
    }

    if (connection === "close") {
      const code = lastDisconnect?.error?.output?.statusCode;

      if (code !== DisconnectReason.loggedOut) {
        console.log("Koneksi terputus, mencoba reconnect...");
        startBot();
      } else {
        console.log("Session logout. Hapus folder session lalu login ulang.");
      }
    }
  });

  sock.ev.on("messages.upsert", async ({ messages }) => {
    const msg = messages[0];
    if (!msg.message || msg.key.fromMe) return;

    const jid = msg.key.remoteJid;
    const text =
      msg.message.conversation ||
      msg.message.extendedTextMessage?.text ||
      "";

    const command = text.trim().toLowerCase();

    if (command === ".menu") {
      await sock.sendMessage(jid, {
        text: `╭─── BOT MENU ───╮
│
│ .menu
│ .ping
│ .info
│ .owner
│
╰─────────────────╯`
      });
    } else if (command === ".ping") {
      await sock.sendMessage(jid, {
        text: "Pong! 🟢 Bot aktif."
      });
    } else if (command === ".info") {
      await sock.sendMessage(jid, {
        text: `🤖 WhatsApp Bot

Status : Online
Runtime: Node.js
Version: 1.0.0`
      });
    } else if (command === ".owner") {
      await sock.sendMessage(jid, {
        text: "Owner: Ganti bagian ini dengan nama kamu."
      });
    }
  });
}

startBot();
