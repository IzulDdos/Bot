# WhatsApp Bot

## Jalankan
```bash
npm install
npm start
```

QR akan muncul di terminal. Scan dengan WhatsApp > Perangkat tertaut.

## Perintah
- `.menu`
- `.ping`
- `.info`
- `.owner`

Jangan upload folder `session/` ke GitHub.
